-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: skill_insights_db
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `applicants`
--

DROP TABLE IF EXISTS `applicants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `applicants` (
  `ApplicantID` int NOT NULL AUTO_INCREMENT,
  `gender` varchar(50) DEFAULT NULL,
  `relevent_experience` varchar(100) DEFAULT NULL,
  `enrolled_university` varchar(100) DEFAULT NULL,
  `education_level` varchar(100) DEFAULT NULL,
  `major_discipline` varchar(100) DEFAULT NULL,
  `experience` varchar(50) DEFAULT NULL,
  `company_size` varchar(10) DEFAULT NULL,
  `company_type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ApplicantID`)
) ENGINE=InnoDB AUTO_INCREMENT=76768 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `courses` (
  `CourseID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) DEFAULT NULL,
  `Provider` varchar(100) DEFAULT NULL,
  `SkillID` int DEFAULT NULL,
  `EnrollmentCount` int DEFAULT NULL,
  PRIMARY KEY (`CourseID`),
  KEY `SkillID` (`SkillID`),
  CONSTRAINT `courses_ibfk_1` FOREIGN KEY (`SkillID`) REFERENCES `skills` (`SkillID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `job_postings`
--

DROP TABLE IF EXISTS `job_postings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_postings` (
  `JobID` int NOT NULL AUTO_INCREMENT,
  `JobTitle` varchar(255) DEFAULT NULL,
  `Company` varchar(255) DEFAULT NULL,
  `Location` varchar(100) DEFAULT NULL,
  `DatePosted` date DEFAULT NULL,
  `SalaryFrom` float DEFAULT NULL,
  `SalaryTo` float DEFAULT NULL,
  `EmploymentType` varchar(50) DEFAULT NULL,
  `Source` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`JobID`)
) ENGINE=InnoDB AUTO_INCREMENT=12627 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `job_skills`
--

DROP TABLE IF EXISTS `job_skills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_skills` (
  `JobID` int NOT NULL,
  `SkillID` int NOT NULL,
  PRIMARY KEY (`JobID`,`SkillID`),
  KEY `SkillID` (`SkillID`),
  CONSTRAINT `job_skills_ibfk_1` FOREIGN KEY (`JobID`) REFERENCES `job_postings` (`JobID`),
  CONSTRAINT `job_skills_ibfk_2` FOREIGN KEY (`SkillID`) REFERENCES `skills` (`SkillID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `raw_skills`
--

DROP TABLE IF EXISTS `raw_skills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `raw_skills` (
  `RawSkillID` int NOT NULL AUTO_INCREMENT,
  `JobID` int DEFAULT NULL,
  `SkillName` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`RawSkillID`),
  KEY `JobID` (`JobID`),
  CONSTRAINT `raw_skills_ibfk_1` FOREIGN KEY (`JobID`) REFERENCES `job_postings` (`JobID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `salaries`
--

DROP TABLE IF EXISTS `salaries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `salaries` (
  `SalaryID` int NOT NULL AUTO_INCREMENT,
  `work_year` int DEFAULT NULL,
  `job_title` varchar(255) DEFAULT NULL,
  `experience_level` varchar(50) DEFAULT NULL,
  `employment_type` varchar(50) DEFAULT NULL,
  `salary_in_usd` float DEFAULT NULL,
  `remote_ratio` int DEFAULT NULL,
  `employee_residence` varchar(100) DEFAULT NULL,
  `company_location` varchar(100) DEFAULT NULL,
  `company_size` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`SalaryID`)
) ENGINE=InnoDB AUTO_INCREMENT=335107 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `salaries_2025`
--

DROP TABLE IF EXISTS `salaries_2025`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `salaries_2025` (
  `SalaryID` int NOT NULL AUTO_INCREMENT,
  `job_title` varchar(255) DEFAULT NULL,
  `experience_level` varchar(50) DEFAULT NULL,
  `employment_type` varchar(50) DEFAULT NULL,
  `salary_in_usd` float DEFAULT NULL,
  `remote_ratio` int DEFAULT NULL,
  `employee_residence` varchar(100) DEFAULT NULL,
  `company_location` varchar(100) DEFAULT NULL,
  `company_size` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`SalaryID`)
) ENGINE=InnoDB AUTO_INCREMENT=842374 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `skills`
--

DROP TABLE IF EXISTS `skills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `skills` (
  `SkillID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  `Category` varchar(100) DEFAULT NULL,
  `PopularityScore` float DEFAULT NULL,
  PRIMARY KEY (`SkillID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `surveys`
--

DROP TABLE IF EXISTS `surveys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `surveys` (
  `SurveyID` int NOT NULL AUTO_INCREMENT,
  `country` varchar(100) DEFAULT NULL,
  `education` varchar(100) DEFAULT NULL,
  `current_role` varchar(100) DEFAULT NULL,
  `python` tinyint(1) DEFAULT NULL,
  `sql` tinyint(1) DEFAULT NULL,
  `r_language` tinyint(1) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `hiring_roles_planned` text,
  `ideal_job_title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`SurveyID`)
) ENGINE=InnoDB AUTO_INCREMENT=24151 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-22  1:36:30
