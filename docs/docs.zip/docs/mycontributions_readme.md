# Project 3: Skill Insights – What Are the Most Valuable Data Science Skills?

**Course**: DAT607  
**Student Name**: Sheriann McLarty  
**Role**: Project Lead / Data Wrangler / Database Architect  
**Date**: March 2025

---

## 📌 Project Summary

This project explores the most valuable and in-demand skills in data science by analyzing job postings, applicant data, salaries, course offerings, and survey responses. The goal was to unify multiple datasets into a structured SQL database and extract insights through data analysis and visualization in R.

---

## 🛠️ Tools & Technologies

- MySQL (Database creation and querying)
- R & RMarkdown (Data analysis and visualization)
- GitHub (Collaboration and version control)
- Slack (Team communication)

---

## 🧩 Datasets Used (Cleaned & Integrated into SQL DB)

1. **clean_ds_applicants.csv** – Contains info on job applicants (e.g., gender, job roles, preferences)
2. **clean_ds_salaries_2025.csv** – Salary data, including job titles, experience, and pay
3. **clean_job_spy_jobs.csv** – Scraped job listings with skills and roles
4. **clean_nyc_jobs_utf8.csv** – NYC-specific job openings
5. **clean_sods_survey_2023.csv** – Survey on data science tools, languages, and opinions

*Each dataset was cleaned, standardized, and imported into the `skill_insights_db`.*

---

## 🧱 Database Structure

The ER diagram includes the following tables:

- `applicants`
- `job_postings`
- `skills`
- `courses`
- `surveys`
- `job_skills` (junction table)

Each table is linked through primary/foreign keys (e.g., `SkillID`, `CourseID`) to allow relational querying.

---

## 💡 Key Responsibilities

- Cleaned and standardized all 5 datasets
- Designed the **ER Diagram** and built the **SQL database** from scratch
- Imported all data using Python scripts and MySQL Workbench
- Created an SQL script to populate and test `skills` and `courses` tables
- Shared SQL schema and DB connection guidance with team members
- Provided backup `.sql` file for DB replication
- Advised teammates on analysis direction and RMarkdown structure

---

## 📊 Team Responsibilities (Division of Work)

- **Sheriann McLarty**: Data cleaning, ER design, database setup, schema scripting, project lead
- **Lawrence Yu**: Job data scraping, data validation, README/deliverable planning
- **Isaias Soto**: Course data cleanup and GitHub hosting
- **Woodelyne D.**: RMarkdown analysis and survey data pivoting
- **Tanzil Ehsan**: Visualization generation and analysis summaries

---

## 🔍 How to Use the Database

1. Import the SQL backup or schema provided (`skill_insights_db_backup_schema.sql`)
2. Use the RMarkdown script to query and visualize from the DB
3. Do **not** use the original CSVs in your analysis—only query from the DB directly

---

## 📈 Sample Insight

> “Python” had the highest popularity score (9.8) and the most enrolled course:  
> **‘Python for Data Science’ (Coursera)** with **42,350** students.

---

## 🗂️ Submission Files

- `skill_insights_db_backup_schema.sql` – Full database backup
- `skills_courses_script.sql` – Script to recreate Skills & Courses tables with sample data
- `README.md` – This file
- ER Diagram
- Updated ER Diagram
- Optional: skills_insight-db_test.Rmd – Used to test DB queries in R

---

## 🧠 Final Thoughts

All data is centralized in one unified SQL database to ensure consistency across team analyses. This project reflects real-world data collaboration, and the structure was designed for scalability and clarity. Visuals and insights should be pulled *only* from the SQL database for accuracy and alignment.

The final ER diagram reflects all tables, relationships, and normalization decisions used to build the database.
---

*If you have any questions, contact the Project Lead. Otherwise… good luck, and may your queries return rows.*
