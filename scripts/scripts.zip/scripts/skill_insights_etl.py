
import pandas as pd
import mysql.connector
from mysql.connector import Error

host = "localhost"
user = "root"
password = "Spring_2025"
database = "skill_insights_db"
connection = None

try:
    connection = mysql.connector.connect(
        host=host,
        user=user,
        password=password,
        database=database
    )

    if connection.is_connected():
        print("✅ Connected to MySQL")
        cursor = connection.cursor()

        # NYC Jobs
        print("\n📦 Importing: clean_nyc_jobs_utf8.csv")

        df = pd.read_csv("C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/clean_nyc_jobs_utf8.csv")

        # Show column names to debug
        print("🧠 COLUMN HEADERS:", df.columns.tolist())

        # Normalize headers
        df.columns = df.columns.str.strip().str.lower()

        # Rename 'title' ➡️ 'JobTitle' (and others if needed)
        df.rename(columns={
            "title": "JobTitle",
            "company": "Company",
            "location": "Location",
            "date_posted": "DatePosted",
            "salary_from": "SalaryFrom",
            "salary_to": "SalaryTo",
            "employment_type": "EmploymentType",
            "source": "Source"  # 👈 this line is crucial
        }, inplace=True)

        # Convert date to MySQL-friendly format
        df["DatePosted"] = pd.to_datetime(df["DatePosted"], errors="coerce").dt.strftime("%Y-%m-%d")

        # Replace NaNs with None for MySQL
        df = df.where(pd.notnull(df), None)
        if "Source" not in df.columns:
            df["Source"] = "NYC"

        # Insert into database
        for _, row in df.iterrows():
            cursor.execute(
                """
                INSERT INTO Job_Postings 
                (JobTitle, Company, Location, DatePosted, SalaryFrom, SalaryTo, EmploymentType, Source)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                """,
                (
                    row["JobTitle"],
                    row["Company"],
                    row["Location"],
                    row["DatePosted"],
                    row["SalaryFrom"],
                    row["SalaryTo"],
                    row["EmploymentType"],
                    row["Source"]
                )
            )

        connection.commit()
        print("✅ NYC Jobs imported.")

        # SODS Survey
        print("\n📦 Importing: clean_sods_survey_2023.csv")
        df = pd.read_csv("C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/clean_sods_survey_2023.csv")
        df.columns = df.columns.str.strip().str.lower()
        df = df.loc[:, ~df.columns.str.lower().isin(['nan'])]
        df = df.replace("nan", None).where(pd.notnull(df), None)
        df = df[[
            "country",
            "education",
            "primary_job_function",
            "python",
            "sql",
            "r_programming",
            "gender",
            "planned_job_postings",
            "what_would_be_your_ideal_job_title__selected_choice"
        ]]
        for _, row in df.iterrows():
            row = row.astype(str).replace("nan", None)

            cursor.execute(
                """
                INSERT INTO Surveys 
                (country, education, current_role, python, `sql`, r_language, gender, hiring_roles_planned, ideal_job_title)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                """,
                (
                    row["country"],
                    row["education"],
                    row["primary_job_function"],
                    row["python"],
                    row["sql"],
                    row["r_programming"],
                    row["gender"],
                    row["planned_job_postings"],
                    row["what_would_be_your_ideal_job_title__selected_choice"]
                )
            )

        connection.commit()
        print("✅ SODS Survey imported.")

        # Global Salaries
        print("\n📦 Importing: clean_ds_salaries.csv")
        df = pd.read_csv("C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/clean_ds_salaries.csv")
        df.columns = df.columns.str.strip().str.lower()
        df = df.where(pd.notnull(df), None)
        for _, row in df.iterrows():
            cursor.execute(
                """
                INSERT INTO Salaries 
                (work_year, job_title, experience_level, employment_type, salary_in_usd, remote_ratio, employee_residence, company_location, company_size)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                """,
                (
                    row["work_year"], row["job_title"], row["experience_level"],
                    row["employment_type"], row["salary_in_usd"], row["remote_ratio"],
                    row["employee_residence"], row["company_location"], row["company_size"]
                )
            )
        connection.commit()
        print("✅ Global Salaries imported.")

        # 2025 Salaries
        print("\n📦 Importing: clean_ds_salaries_2025.csv")
        df = pd.read_csv("C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/clean_ds_salaries_2025.csv")
        df.columns = df.columns.str.strip().str.lower()
        df = df.where(pd.notnull(df), None)
        for _, row in df.iterrows():
            cursor.execute(
                """
                INSERT INTO Salaries_2025 
                (job_title, experience_level, employment_type, salary_in_usd, remote_ratio, employee_residence, company_location, company_size)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                """,
                (
                    row["job_title"], row["experience_level"], row["employment_type"],
                    row["salary_in_usd"], row["remote_ratio"], row["employee_residence"],
                    row["company_location"], row["company_size"]
                )
            )
        connection.commit()
        print("✅ 2025 Salaries imported.")

        # DS Applicants
        print("\n📦 Importing: clean_ds_applicants.csv")
        df = pd.read_csv("C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/clean_ds_applicants.csv")
        df.columns = df.columns.str.strip().str.lower()
        df = df.where(pd.notnull(df), None)
        for _, row in df.iterrows():
            row = row.astype(str).replace("nan", None)

            cursor.execute(
                """
                INSERT INTO Applicants 
                (gender, relevent_experience, enrolled_university, education_level, major_discipline, experience, company_size, company_type)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                """,
                (
                    row["gender"], row["relevent_experience"], row["enrolled_university"],
                    row["education_level"], row["major_discipline"], row["experience"],
                    row["company_size"], row["company_type"]
                )
            )
        connection.commit()
        print("✅ DS Applicants imported.")

except Error as e:
    print(f"❌ MySQL Error: {e}")
except Exception as e:
    print(f"❌ General Error: {e}")
finally:
    if connection and connection.is_connected():
        cursor.close()
        connection.close()
        print("✅ MySQL connection closed.")

{
    "filename": "clean_job_spy_jobs.csv",
    "table": "Job_Postings",
    "columns": [
        "JobTitle",
        "Company",
        "Location",
        "DatePosted",
        "SalaryFrom",
        "SalaryTo",
        "EmploymentType",
        "Source"
    ]
},
