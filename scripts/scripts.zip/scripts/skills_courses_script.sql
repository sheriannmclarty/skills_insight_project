-- Project: Skill Insights - Group 3
-- Author: Sheriann McLarty (Project Lead)
-- Description: Full schema and sample data for data science skill analysis
-- Last Updated: 2025-03-22

-- Drop database if exists (for reset)
DROP DATABASE IF EXISTS skill_insights_db;
CREATE DATABASE skill_insights_db;
USE skill_insights_db;

-- Table: Skills
CREATE TABLE Skills (
    SkillID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(100),
    Category VARCHAR(100),
    PopularityScore FLOAT
);

-- Table: Courses
CREATE TABLE Courses (
    CourseID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(255),
    Provider VARCHAR(100),
    SkillID INT,
    EnrollmentCount INT,
    FOREIGN KEY (SkillID) REFERENCES Skills(SkillID)
);

-- Insert sample Skills
INSERT INTO Skills (Name, Category, PopularityScore) VALUES
('Python', 'Programming Language', 9.8),
('SQL', 'Database Language', 9.5),
('R', 'Programming Language', 8.7),
('Excel', 'Tool', 7.0),
('Machine Learning', 'Concept', 9.2),
('Data Visualization', 'Tool', 8.5),
('Tableau', 'Visualization Tool', 8.0),
('Power BI', 'Visualization Tool', 7.8),
('AWS', 'Cloud Platform', 8.3),
('Spark', 'Big Data Tool', 7.5),
('TensorFlow', 'Machine Learning Framework', 8.9),
('Communication', 'Soft Skill', 9.0);

-- Insert sample Courses
INSERT INTO Courses (Name, Provider, SkillID, EnrollmentCount) VALUES
('Python for Data Science', 'Coursera', 1, 42350),
('Data Visualization with Tableau', 'Udemy', 7, 19000),
('Power BI for Beginners', 'edX', 8, 15000),
('AWS Fundamentals', 'Coursera', 9, 27000),
('Big Data with Apache Spark', 'DataCamp', 10, 22000),
('TensorFlow for Deep Learning', 'Coursera', 11, 33000),
('Effective Communication for Data Scientists', 'LinkedIn Learning', 12, 12000);

-- Preview Query to Join Courses and Skills
SELECT
    c.CourseID,
    c.Name AS CourseName,
    c.Provider,
    s.Name AS SkillName,
    s.PopularityScore,
    c.EnrollmentCount
FROM Courses c
JOIN Skills s ON c.SkillID = s.SkillID;

-- End of Script
